<footer class="main-footer">
    Tüm hakları saklıdır.

    <div class="float-right d-none d-sm-inline-block">

        <strong> &copy; 2024 </strong>
    </div>
</footer>